import pandas as pd
import sys

# Vérifie si le bon nombre d'arguments a été passé en ligne de commande
if len(sys.argv) != 2:
    print("Usage: python tri_et_division_csv.py <fichier_csv>")
    sys.exit(1)

# Récupère le nom du fichier CSV depuis les arguments en ligne de commande
fichier_csv = sys.argv[1]

# Charge le fichier CSV dans un DataFrame
df = pd.read_csv(fichier_csv)

# Trie le DataFrame selon la dernière colonne
df_trie = df.sort_values(by=df.columns[-1])

# Divise le DataFrame en plusieurs DataFrames selon la dernière colonne
groupes = df_trie.groupby(df_trie.columns[-1])

# Enregistre chaque groupe dans un fichier CSV séparé
for nom_groupe, groupe in groupes:
    nom_fichier_sortie = f"{fichier_csv.split('.')[0]}_{nom_groupe}.csv"
    groupe.to_csv(nom_fichier_sortie, index=False)
    print(f"Fichier {nom_fichier_sortie} créé avec succès")
