import pandas as pd
import matplotlib.pyplot as plt

# Lire le fichier CSV (remplacez 'votre_fichier.csv' par le chemin vers votre fichier)
df = pd.read_csv('72_distributions.csv')

# Vérifier si le fichier a au moins trois colonnes
if df.shape[1] >= 4:
    # Extraire la colonne 1, colonne 2 et colonne 3
    colonne_1 = df.iloc[:, 0]  # Colonne 1 (index 0)
    colonne_2 = df.iloc[:, 1]  # Colonne 2 (index 1)
    colonne_3 = df.iloc[:, 2]  # Colonne 3 (index 2)
    colonne_4 = df.iloc[:, 3]  # Colonne 4 (index 3)
    colonne_5 = df.iloc[:, 4]  # Colonne 5 (index 4)
    
    # Tracer la distribution de la colonne 2 par rapport à la colonne 1
    plt.figure(figsize=(8, 6))
    plt.scatter(colonne_1, colonne_2, color='blue', alpha=0.6, edgecolors='w', label='BNs vs BAC score')
    
    # Ajouter une ligne horizontale rouge basée sur la valeur de la colonne 3
    valeur_ligne_rouge = colonne_3.mean()  # Par exemple, on peut utiliser la moyenne de la colonne 3
    valeur_ligne_verte = colonne_4.mean()  # Par exemple, on peut utiliser la moyenne de la colonne 4
    valeur_ligne_bleue = colonne_5.mean()  # Par exemple, on peut utiliser la moyenne de la colonne 5
    
    plt.axhline(y=valeur_ligne_rouge, color='red', linestyle='--', label=f'no tolerance BAC = {valeur_ligne_rouge:.2f}')
    plt.axhline(y=valeur_ligne_verte, color='green', linestyle='--', label=f'union BNs BAC = {valeur_ligne_verte:.2f}')
    plt.axhline(y=valeur_ligne_bleue, color='blue', linestyle='--', label=f'average BNs BAC = {valeur_ligne_bleue:.2f}')
    
    # Ajouter des labels et un titre
    plt.xlabel('# Boolean networks')
    plt.ylabel('BAC score')
    plt.title('Distribution of the BAC score in relation to BNs obtained')
    plt.legend()
    
    # Afficher le graphique
    plt.show()
    
else:
    print("Le fichier CSV doit contenir au moins trois colonnes.")

