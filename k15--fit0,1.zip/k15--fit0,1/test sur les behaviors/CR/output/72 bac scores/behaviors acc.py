import csv

def count_matches(file_name):
    cr_count_total = 0
    resistant_count_total = 0
    bac_count = 0

    # Open the CSV file for reading
    with open(file_name, newline='') as csvfile:
        reader = csv.reader(csvfile)
        rows = list(reader)

        # Ensure there are at least 101 rows for the 100 rows of comparison
        if len(rows) < 101:
            print("Not enough rows in the CSV file.")
            return
        
        # Iterate over all columns from 2 to 73 (i.e., columns 1 to 72, where column 1 is index 0)
        for col_index in range(1, 73):  # From Column 2 (index 1) to Column 73 (index 72)
            cr_count = 0
            resistant_count = 0
            

            # Compare Column 1 with each of the columns from 2 to 73
            for i in range(1, 101):  # Rows 1 to 100 (assuming 0 is the header row)
                column_a = rows[i][0]  # Column 1 (index 0)
                column_x = rows[i][col_index]  # Current column being compared (2 to 73)

                if column_a == "CR" and column_x == "CR":
                    cr_count += 1
                if column_a == "RESISTANT" and column_x == "RESISTANT":
                    resistant_count += 1

            # Update total counts for CR and RESISTANT
            cr_count_total += cr_count
            resistant_count_total += resistant_count
            acc_cr = round(cr_count/72, 3)
            acc_resistant= round(resistant_count/28, 3)
            bac = round((acc_cr + acc_resistant) / 2 , 3)
            bac_count=bac_count+bac

            print(f"Column {col_index + 1}: CR acc: {acc_cr}, RESISTANT acc: {acc_resistant}, bac: {bac}")

    
    print(f'Total CR count: {cr_count_total}')
    print(f'Total RESISTANT count: {resistant_count_total}')
    bac_total=bac_count/72
    print(f'BAC score: {bac_total}')


# Usage
# Replace 'your_file.csv' with the path to your CSV file
count_matches('fichier_fusionne.csv')

