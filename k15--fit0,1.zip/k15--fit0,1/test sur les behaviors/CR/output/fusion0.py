import pandas as pd

def fusionner_fichiers_csv(fichier1, fichier2, fichier_sortie):
    # Charger les fichiers CSV dans des DataFrames pandas
    df1 = pd.read_csv(fichier1)
    #df2 = pd.read_csv(fichier2, usecols=[1])  # Charger uniquement la deuxième colonne
    df2 = pd.read_csv(fichier2)
    # Fusionner les DataFrames en utilisant la méthode concat de pandas
    resultat_fusion = pd.concat([df1, df2], axis=1)

    # Enregistrer le résultat dans un nouveau fichier CSV
    resultat_fusion.to_csv(fichier_sortie, index=False)

if __name__ == "__main__":    
    i=1
    fichier_sortie = 'fichier_fusionne.csv'
    
    while i<73:
        # Spécifier les noms des fichiers CSV et le fichier de sortie
        fichier1 = 'results_test_'+"%s" % i+'.csv'
        #fichier1 = f'results_test_{i}.csv'
        #fichier2 = 'results_test_9.csv'
        

	# Appeler la fonction de fusion
        fusionner_fichiers_csv(fichier_sortie, fichier1, fichier_sortie)
        i+=1
        
