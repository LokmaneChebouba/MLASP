import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
df = pd.DataFrame({'k': [5, 10, 15, 20, ],
                   'scenario 1': [0, 0.42, 0, 0.50],
                   'scenario 2': [0, 0.46, 0.49, 0],
                   'scenario 3': [0, 0.44, 0.66, 0.62],
                   })

print(df)

dfm = df.melt('k', var_name='approach', value_name='bac score')
g = sns.catplot(x="k", y="bac score", hue='approach', data=dfm, kind='point')

plt.show()
