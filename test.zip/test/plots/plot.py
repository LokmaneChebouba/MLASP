import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
df = pd.DataFrame({'k': [5, 10, 15, 20, ],
                   'all graph': [0, 0.415674603174603, 0, 0.50297619047619],
                   'k/22': [0, 0.5, 0.516865079365079, 0.530753968253968],
                   '74 graph': [0, 0.444444444444444, 0.656746031746032, 0.615079365079365],
                   })

print(df)

dfm = df.melt('k', var_name='approach', value_name='bac score')
g = sns.catplot(x="k", y="bac score", hue='approach', data=dfm, kind='point')

plt.show()
