import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
df = pd.DataFrame({'k': [5, 10, 15, 20, ],
                   'all graph': [24, 26, 0, 4],
                   'k/22': [34, 27, 11, 3],
                   '74 graph': [30, 26, 8, 5],
                   })

print(df)

dfm = df.melt('k', var_name='approach', value_name='#patients')
g = sns.catplot(x="k", y="#patients", hue='approach', data=dfm, kind='point')

plt.show()
