import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
df = pd.DataFrame({'k': [5, 10, 15, 20, ],
                   'scenario 1': [24, 26, 0, 4],
                   'scenario 2': [25, 25, 10, 3],
                   'scenario 3': [30, 26, 8, 5],
                   })

print(df)

dfm = df.melt('k', var_name='approach', value_name='#patients')
g = sns.catplot(x="k", y="#patients", hue='approach', data=dfm, kind='point')

plt.show()
