# Crée des Midas séparées pour les patients du test
#passer le fichier data en paramètre
#python patients_unitaires.py CR_Discretisation_Trikmeans_testing.csv

import os
import sys
import csv


file=open(sys.argv[1],'r')
reader = csv.reader(file)
#for row in reader:
#	print (row)
#file=open(sys.argv[1],'r')
data=file.readlines()

file.close()
#chargement de la liste des prot
liste=[]
liste2=[]
for i in data:
	liste.append(i.split("\n")[0])


#print (liste[0]).

n=1
while n<101:
	liste2=liste[n].split(",")



	i=4
	while i<6:
		liste2[i]='0'
		i += 1

	#print (liste2[56])
	print(liste2)

	#ouverture en ajout
#	f = open(sys.argv[2],'a')
	f=open('PR_test'+"%s" % n+'.csv', 'a')
	f.write(liste[0])
	#ajouter un saut de ligne
	f.write("\n")
	#écriture
	#f.write("laverda")
	i=0
	k=0
	for i in liste2:
		f.write("%s" % i)
		k+=1
		if k<len(liste2):
			f.write(",")	

	f.write("\n")
	f.write(liste[n])
	#ajouter un saut de ligne

	#fermeture
	f.close()
	n+=1

