import matplotlib.pyplot as plt
import numpy as np

real= np.array([1,0,1,1,1,0,1,1,1,1,1,1,1,1,1,0,1,0,1,1,0,1,0,0,0,1,1,1,0,0,0,1,0,0,1,1,1,1,0,0,1,1,0,1,1,1,1,1,0,1,0,1,1,1,0,0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,0,1,1,0,1,1,1,1,1,1,1,0,1,1,1,1,0,1,1,0,1,1,1,0])
predict = np.array([0,0,1,1,0,0,0,1,0,1,0,0,0,1,0,0,1,0,0,0,1,0,0,0,0,1,1,0,0,0,0,0,0,0,1,0,1,0,0,1,1,1,1,0,1,1,1,0,0,0,0,0,0,1,1,1,1,1,1,1,0,0,1,0,0,1,1,1,1,1,0,1,0,0,0,0,0,1,1,0,1,0,1,0,1,0,1,1,0,1,0,1,0,1,0,0,1,1,0,0])

# false positive rate
fpr = []
# true positive rate
tpr = []
#Iterate thresholds from 0.0, 0.01, ... 1.0
thresholds = np.arange(0.0, 1.01, .01)

# get number of positive and negative examples in the dataset
P = sum(real)
N = len(real) - P

# iterate through all thresholds and determine fraction of true positives
# and false positives found at this threshold
for thresh in thresholds:
    FP=0
    TP=0
    FN=0
    TN=0
    for i in range(len(predict)):
        for i in range(len(predict)):
            if (predict[i] == 1 & real[i]==1):
                TP = TP + 1
            if (predict[i] == 1 & real[i]==0):
                FP = FP + 1

        for j in range(len(predict)):
            if (predict[j] == 0 and real[j] == 0):
                TN = TN + 1
            if (predict[j] == 0 and real[j] == 1):
                FN = FN + 1
    
    fpr.append(FP/N)
    tpr.append(TP/P)
    
TP=TP*0.01
TN=TN*0.01
FP=FP*0.01
FN=FN*0.01
print("P: ", P)
print("N: ", N)
print("TP: ", TP)
print("FP: ", FP)
print("TN: ", TN)
print("FN: ", FN)


bac_score=1/2 * ((TP/P)+(TN/N))
print("Bac score: ",bac_score)

fpr.append(FP/float(N))
tpr.append(TP/float(P))

print("FPR",fpr)
print("TPR",tpr)

#you're integrating from right to left. This flips the sign of the result
auc = -1 * np.trapz(tpr, fpr)
print('auc:', auc)


plt.plot(fpr, tpr)
plt.show()
