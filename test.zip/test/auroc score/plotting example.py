import matplotlib.pyplot as plt
import numpy as np

x = [0.13, 0.26, 0.08, 0.19, 0.34]
y = [0, 0, 1, 1, 1]

# This is the ROC curve
plt.plot(x,y)
plt.show() 

# This is the AUC
auc = np.trapz(y,x)
