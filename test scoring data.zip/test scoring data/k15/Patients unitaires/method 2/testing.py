#source activate caspo-env
#python testing.py

from caspo import core

i=1
while i<101:
	networks1 = core.LogicalNetworkList.from_csv('behaviorscr.csv')
	networks2 = core.LogicalNetworkList.from_csv('behaviorspr.csv')
	dataset1 = core.Dataset('patients unitaires/test'+"%s" % i+'.csv', 10)
	#dataset2 = core.Dataset('patients unitaires/PR_test'+"%s" % i+'.csv', 10)

	msecr=networks1.weighted_mse(dataset1)
	msepr=networks2.weighted_mse(dataset1)
	#print 'msecr'+"%s" % i+'=', msecr
	#print 'msepr'+"%s" % i+'=', msepr
	#ouverture en ajout
	f=open('results_test.txt', 'a')
	f.write('patient number'+str(i)+':')
	f.write('\n')
	f.write('msecr= ')
	f.write (str(msecr))
	f.write('\n')
	f.write('msepr= ')
	f.write (str(msepr))
	f.write('\n')
	if(msecr<msepr):
		f.write('prediction pour patient number'+str(i)+'est: Complete Remission')
	else:
		if(msepr<msecr):
			f.write('prediction pour patient number'+str(i)+'est: Primary Resistant')
		else:
			f.write('Can\'t judge')
		
	f.write('\n')
	f.write('===========================')
	#ajouter un saut de ligne
	f.write("\n")
	f.close()
	i+=1
